# Grimoire PWA release

This release is the v6.69 application shell packaged for HTTPS hosting as an installable Progressive Web App.

## Important data boundary
- This repository contains application code and PWA shell assets only.
- Do not commit campaign notes, stat blocks, images imported by the user, backups, or other personal campaign data.
- Application data remains in the browser's local storage / IndexedDB on the device. This release does not add cloud sync.
- v6.69 remains preserved separately in the private `Grimoire-Dev` repository.

## Hosting
The repository is intended for GitHub Pages. The workflow in `.github/workflows/pages.yml` publishes the repository root when GitHub Pages is configured to use GitHub Actions.

## Storage note
This PWA wrapper provides a stable HTTPS origin and an offline-cached app shell. It does not claim to migrate every application store to IndexedDB; several v6.69 features still use localStorage. A separate migration must be implemented and tested before describing the whole app as IndexedDB-backed.
